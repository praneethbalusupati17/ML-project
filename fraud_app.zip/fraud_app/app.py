import io
import base64
import uuid
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from flask import Flask, render_template, request, send_file, abort

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import IsolationForest
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
)

warnings.filterwarnings("ignore")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 300 * 1024 * 1024  # 300 MB

DOWNLOADS = {}          # id -> csv bytes of suspicious transactions
ROW_LIMIT = 200         # rows shown per table on the page

TARGET_NAMES = [
    "Class", "class", "Fraud", "fraud", "IsFraud", "is_fraud", "Fraud_Flag",
    "fraud_flag", "FraudFlag", "fraudflag", "Target", "target", "Label",
    "label", "Is_Fraud", "isFraud",
]
LEGIT_WORDS = {"0", "legitimate", "normal", "genuine", "valid",
               "not fraud", "non-fraud", "non_fraud"}
FRAUD_WORDS = {"1", "fraud", "fraudulent", "anomaly", "anomalous"}


def to_png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


def table(df, limit=None, index=True):
    if limit is not None:
        df = df.head(limit)
    return df.to_html(classes="data", border=0, index=index, na_rep="")


def bar_chart(labels, values, title, xlabel, ylabel):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(labels, values, color="#2f5d62")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    for i, v in enumerate(values):
        ax.text(i, v, f"{v:,}", ha="center", va="bottom", fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)
    return to_png(fig)


def normalise_target(series):
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().all():
        values = sorted(numeric.unique())
        if set(values).issubset({0, 1}):
            return numeric.astype(int)
        if len(values) == 2:
            return numeric.map({values[0]: 0, values[1]: 1}).astype(int)
        raise ValueError("Target column must contain two classes.")

    text = series.astype(str).str.strip().str.lower()
    out = text.map(lambda v: 0 if v in LEGIT_WORDS else (1 if v in FRAUD_WORDS else np.nan))
    if out.isnull().any():
        raise ValueError("Could not understand all target values. "
                         "Use 0/1 or labels such as Fraud/Legitimate.")
    return out.astype(int)


def run_pipeline(df, file_name):
    out = {"file_name": file_name}

    # ---- dataset information
    total = len(df)
    out["info"] = {
        "rows": total,
        "cols": len(df.columns),
        "missing": int(df.isnull().sum().sum()),
        "duplicates": int(df.duplicated().sum()),
    }
    out["head"] = table(df, 5)
    out["dtypes"] = table(df.dtypes.astype(str).rename("Data type").to_frame())

    # ---- target detection
    target = next((c for c in df.columns if c in TARGET_NAMES), None)
    if target is None:
        raise ValueError(
            "No fraud/target column detected. Rename your label column to one of: "
            "Class, Fraud, IsFraud, Is_Fraud, Fraud_Flag, Target or Label. "
            "Columns found: " + ", ".join(map(str, df.columns))
        )
    out["target"] = target
    out["target_raw"] = table(df[target].value_counts().rename("Count").to_frame())

    df = df.copy()
    df[target] = normalise_target(df[target])
    if df[target].nunique() != 2:
        raise ValueError("The target column must contain exactly two classes.")

    legit = int((df[target] == 0).sum())
    fraud = int((df[target] == 1).sum())
    out["counts"] = {
        "legit": legit, "fraud": fraud,
        "legit_pct": legit / total * 100, "fraud_pct": fraud / total * 100,
    }
    out["chart_classes"] = bar_chart(
        ["Legitimate", "Fraud"], [legit, fraud],
        "Legitimate vs Fraudulent Transactions",
        "Transaction Type", "Number of Transactions")

    # ---- feature preparation
    X = df.drop(columns=[target])
    y = df[target]

    id_cols = [c for c in X.columns
               if "transaction_id" in c.lower() or c.lower() == "id" or c.lower().endswith("_id")]
    X = X.drop(columns=id_cols)
    out["id_cols"] = id_cols

    processed_dates = []
    for c in list(X.columns):
        if "date" in c.lower() or "time" in c.lower():
            try:
                conv = pd.to_datetime(X[c], errors="coerce")
                if conv.notna().mean() > 0.8:
                    X[c + "_year"] = conv.dt.year
                    X[c + "_month"] = conv.dt.month
                    X[c + "_day"] = conv.dt.day
                    X[c + "_hour"] = conv.dt.hour
                    X = X.drop(columns=[c])
                    processed_dates.append(c)
            except Exception:
                pass
    out["date_cols"] = processed_dates

    cat_cols = X.select_dtypes(include=["object", "category", "bool"]).columns.tolist()
    out["cat_cols"] = cat_cols
    if cat_cols:
        X = pd.get_dummies(X, columns=cat_cols, drop_first=True)

    X = X.apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    out["missing_before"] = int(X.isnull().sum().sum())

    X_imp = SimpleImputer(strategy="median").fit_transform(X)
    X_scaled = StandardScaler().fit_transform(X_imp)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.20, random_state=42, stratify=y)
    out["split"] = {"train": len(X_train), "test": len(X_test)}

    # ---- models
    lr = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    lr.fit(X_train, y_train)
    lr_pred = lr.predict(X_test)

    svm = SVC(class_weight="balanced", random_state=42)
    svm.fit(X_train, y_train)
    svm_pred = svm.predict(X_test)

    contamination = float(np.clip(y_train.mean(), 0.01, 0.10))
    out["contamination"] = contamination
    iso = IsolationForest(contamination=contamination, random_state=42, n_estimators=200)
    iso.fit(X_train)
    iso_pred = np.where(iso.predict(X_test) == -1, 1, 0)

    preds = {
        "Logistic Regression": lr_pred,
        "SVM": svm_pred,
        "Isolation Forest": iso_pred,
    }

    # ---- evaluation
    rows = []
    for name, p in preds.items():
        rows.append({
            "Model": name,
            "Accuracy": accuracy_score(y_test, p),
            "Precision": precision_score(y_test, p, zero_division=0),
            "Recall": recall_score(y_test, p, zero_division=0),
            "F1 Score": f1_score(y_test, p, zero_division=0),
            "Fraud Detected": int((p == 1).sum()),
        })
    res = pd.DataFrame(rows).set_index("Model")
    out["metrics"] = res.to_html(
        classes="data", border=0,
        formatters={c: "{:.4f}".format for c in ["Accuracy", "Precision", "Recall", "F1 Score"]})

    out["models"] = []
    for name, p in preds.items():
        cm = confusion_matrix(y_test, p, labels=[0, 1])
        fig, ax = plt.subplots(figsize=(4.6, 3.9))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                    xticklabels=["Legitimate", "Fraud"], yticklabels=["Legitimate", "Fraud"])
        ax.set_title(name + " - Confusion Matrix")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        report = classification_report(
            y_test, p, labels=[0, 1], target_names=["Legitimate", "Fraud"], zero_division=0)
        out["models"].append({"name": name, "cm": to_png(fig), "report": report})

    # ---- summary
    actual_fraud = int((y_test == 1).sum())
    out["summary"] = {
        "actual_fraud": actual_fraud,
        "actual_legit": int((y_test == 0).sum()),
        "detected": {n: int((p == 1).sum()) for n, p in preds.items()},
    }

    # ---- predictions + voting
    pr = df.loc[y_test.index].copy()
    pr["Logistic_Regression"] = lr_pred
    pr["SVM"] = svm_pred
    pr["Isolation_Forest"] = iso_pred
    pr["Fraud_Votes"] = pr["Logistic_Regression"] + pr["SVM"] + pr["Isolation_Forest"]
    pr["Final_Risk"] = pr["Fraud_Votes"].map(
        lambda v: "HIGH FRAUD RISK" if v >= 2 else ("POSSIBLE FRAUD" if v == 1 else "LEGITIMATE"))

    suspicious = pr[pr["Final_Risk"].isin(["HIGH FRAUD RISK", "POSSIBLE FRAUD"])]
    high = pr[pr["Final_Risk"] == "HIGH FRAUD RISK"]

    out["pred_table"] = table(pr, 30)
    out["suspicious_count"] = len(suspicious)
    out["suspicious_table"] = table(suspicious, ROW_LIMIT)
    out["high_count"] = len(high)
    out["high_table"] = table(high, ROW_LIMIT)
    out["row_limit"] = ROW_LIMIT

    order = ["HIGH FRAUD RISK", "POSSIBLE FRAUD", "LEGITIMATE"]
    risk_counts = pr["Final_Risk"].value_counts().reindex(order, fill_value=0)
    out["risk_table"] = table(risk_counts.rename("Count").to_frame())
    out["chart_risk"] = bar_chart(order, [int(v) for v in risk_counts.values],
                                  "Final Transaction Risk Distribution",
                                  "Risk Category", "Number of Transactions")
    out["chart_models"] = bar_chart(list(preds.keys()),
                                    list(out["summary"]["detected"].values()),
                                    "Fraud/Anomaly Detection by Model",
                                    "Machine Learning Model",
                                    "Fraudulent Transactions Detected")

    token = uuid.uuid4().hex
    DOWNLOADS[token] = suspicious.to_csv().encode()
    out["download"] = token
    return out


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html", r=None, error=None)

    f = request.files.get("dataset")
    if not f or not f.filename:
        return render_template("index.html", r=None, error="Please choose a file first.")

    name = f.filename
    try:
        if name.lower().endswith(".csv"):
            df = pd.read_csv(f)
        elif name.lower().endswith((".xlsx", ".xls")):
            df = pd.read_excel(f)
        else:
            raise ValueError("Unsupported file format. Please upload CSV or Excel.")
        result = run_pipeline(df, name)
    except Exception as e:
        return render_template("index.html", r=None, error=str(e))

    return render_template("index.html", r=result, error=None)


@app.route("/download/<token>")
def download(token):
    data = DOWNLOADS.get(token)
    if data is None:
        abort(404)
    return send_file(io.BytesIO(data), mimetype="text/csv",
                     as_attachment=True, download_name="suspicious_transactions.csv")


if __name__ == "__main__":
    app.run(debug=False, port=5000)
